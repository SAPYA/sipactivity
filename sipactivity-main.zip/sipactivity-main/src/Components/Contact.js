import React from 'react'

const Contact = () => {
  return (
    <>
    <h1>Contact Page</h1>
    </>
  )
}

export default Contact